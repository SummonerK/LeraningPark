//
//  Bridging-Header.h
//  XfFruit
//
//  Created by 非码 on 17/4/28.
//  Copyright © 2017年 非码. All rights reserved.
//

//#ifndef Bridging_Header_h
//#define Bridging_Header_h

#import <UIKit/UIKit.h>
#import <AlipaySDK/AlipaySDK.h>
#import "WXApi.h"
#import "UPPaymentControl.h"

//#endif /* Bridging_Header_h */
