//
//  BaseResponse.swift
//  XfFruit
//
//  Created by 非码 on 17/6/9.
//  Copyright © 2017年 非码. All rights reserved.
//

import Foundation
import ObjectMapper

class BaseResponse:Mappable {
    var statusCode:Int?
    var message:String?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        statusCode <- map["statusCode"]
        message <- map["message"]
    }
    
    public var description: String {
        return self.toJSONString()!
    }
}
