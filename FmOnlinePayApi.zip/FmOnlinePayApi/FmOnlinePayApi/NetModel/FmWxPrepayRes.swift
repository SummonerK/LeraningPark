//
//  FmWxPrepayRes.swift
//  FmOnlinePayApi
//
//  Created by 舒圆波 on 17/8/24.
//  Copyright © 2017年 舒圆波. All rights reserved.
//

import Foundation
import ObjectMapper

/*
 微信预支付响应
 */
class FmWxPrepayRes:BaseResponse {
    var fmId:String?                        //非码流水号
    var paymentMethodCode:String?           //支付方式类型
    var paymentMethod:String?               //支付方式名称
    var sign:String?                        //签名
    var responseData:FmWxPrepayDataRes?                //预支付响应
    var payTransId:String?                  //支付交易号
    
    
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        fmId <- map["fmId"]
        paymentMethodCode <- map["paymentMethodCode"]
        paymentMethod <- map["paymentMethod"]
        sign <- map["sign"]
        responseData <- map["responseData"]
        payTransId <- map["payTransId"]
    }
    
    
}

class FmWxPrepayDataRes:Mappable {
    var appid:String?                       //应用id
    var partnerid:String?                   //预订单id
    var prepayid:String?
    var package:String?
    var noncestr:String?
    var timestamp:String?
    var biz_content:String?                 //支付内容
    var tn:String?                                 //银联支付号
    
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        partnerid <- map["partnerid"]
        prepayid <- map["prepayid"]
        package <- map["package"]
        noncestr <- map["noncestr"]
        timestamp <- map["timestamp"]
        appid <- map["appid"]
        biz_content <- map["biz_content"]
        tn <- map["tn"]
    }
    
    public var description: String {
        return self.toJSONString()!
    }
}
