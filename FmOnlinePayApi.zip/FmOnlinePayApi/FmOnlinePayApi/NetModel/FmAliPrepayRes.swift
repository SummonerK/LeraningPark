//
//  FmWxPrepayRes.swift
//  FmOnlinePayApi
//
//  Created by 舒圆波 on 17/8/24.
//  Copyright © 2017年 舒圆波. All rights reserved.
//

import Foundation
import ObjectMapper

/*
 支付宝支付成功响应
 */
class FmPayCallBackRes:Mappable {
    var resultCode:Int?                     //回调码
    var resultMsg:String?                   //提示信息
    var responseData:FmPayCallBackData?     //支付宝返回的交易信息 微信没有

    
    
    
    init() {
       
    }
    
    required init?(map: Map) {
        
    }
    
    
    public var description: String {
        return self.toJSONString()!
    }
    

    
    func mapping(map: Map) {
        resultCode <- map["resultCode"]
        resultMsg <- map["resultMsg"]
        responseData <- map["responseData"]
    }
    
    
}

class FmPayCallBackData:Mappable {
    var timestamp:String?                   //交易完成时间
    var totalAmount:String?                 //交易金额
    var tradeNo:String?                     //支付宝交易序号
    var sellerId:String?                    //售卖id
    var outTradeNo:String?                  //非码交易号
    var fmId:String?                        //非码订单号
    
    init() {
        
    }
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        timestamp <- map["timestamp"]
        totalAmount <- map["total_amount"]
        tradeNo <- map["trade_no"]
        outTradeNo <- map["out_trade_no"]
        sellerId <- map["sellerId"]
        fmId <- map["fmId"]
    }
    
    public var description: String {
        return self.toJSONString()!
    }
}


