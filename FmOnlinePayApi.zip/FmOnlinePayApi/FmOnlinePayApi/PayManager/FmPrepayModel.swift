//
//  CreateOrderReq.swift
//  XfFruit
//
//  Created by 非码 on 17/6/29.
//  Copyright © 2017年 非码. All rights reserved.
//

import Foundation
import ObjectMapper

/*
    支付model
 */
class FmPrepayModel:Mappable {
    var ver:Int!                        //接口版本 当前默认1
    var partnerId:Int?                  //商户Id,由非码后台分配
    var storeId:String!                 //商家门店号,不填默认为"-1"
    var stationId:String!               //设备终端号,不填默认为"-1"
    var partnerOrderId:String?          //商户交易订单号
    var paymentMethodCode:String?       //支付方式  20002支付宝 20001微信
//    var transDate:String?               //交易日期（格式yyyy-MM-dd HH:mm:ss）
    var transAmount:Int?                //支付总金额 以分为单位
    var undiscountAmount:Int!           //不可打折金额 以分为单位  非必要
    var products:[FmPayProductModel]?   //商品数组
    var sign:String?                    //签名
    
    init() {
        self.ver = 1
        self.storeId = "-1"
        self.stationId = "-1"
        self.undiscountAmount = 0
    }
    
    required init?(map: Map) {
        
    }
    
    
    public var description: String {
        return self.toJSONString()!
    }
    
    
    func mapping(map: Map) {
        ver <- map["ver"]
        partnerId <- map["partnerId"]
        storeId <- map["storeId"]
        stationId <- map["stationId"]
        partnerOrderId <- map["partnerOrderId"]
        paymentMethodCode <- map["paymentMethodCode"]
        transAmount <- map["transAmount"]
        undiscountAmount <- map["undiscountAmount"]
        products <- map["products"]
        sign <- map["sign"]
    }
}

/*支付商品model
 */
class FmPayProductModel:Mappable {
    var pid:String?                 //商品id
    var name:String?                //商品名字
    var consumeNum:Int?             //商品数量
    var price:Int?                  //商品单价  分单位
    var salesType:String!           //售卖类型  可选值FREE(免费) NORMAL(正常)
    
    
    init() {
        self.salesType = "NORMAL"
    }
    
    required init?(map: Map) {
        
    }
    
    
    public var description: String {
        return self.toJSONString()!
    }
    
    
    func mapping(map: Map) {
        pid <- map["pid"]
        name <- map["name"]
        consumeNum <- map["consumeNum"]
        price <- map["price"]
        salesType <- map["salesType"]
    }
}

