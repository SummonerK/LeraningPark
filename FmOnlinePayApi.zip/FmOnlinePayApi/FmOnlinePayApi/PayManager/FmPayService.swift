//
//  MemberService.swift
//  XfFruit
//
//  Created by 非码 on 17/6/2.
//  Copyright © 2017年 非码. All rights reserved.
//

import Foundation
import Moya
import RxSwift

enum FmPayService {
   
    case getPaySign(req:FmPrepayModel)             //获取支付签名
}

func jsonToDictionary(jsonString:String) -> [String:Any] {
    
    let jsonData:Data  = jsonString.data(using: .utf8)!
    let dict = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers)
    if dict != nil {
        return dict as! [String:Any]
    }
    return NSDictionary() as! [String : Any]
}
let FmSignKey = ""


let logPlugin = NetworkLoggerPlugin.init(verbose: true, cURL: true, output: {(_ separator: String, _ terminator: String, _ items: Any...) in
    for item in items{
        
//        print("---\((item as! String).replacingOccurrences(of: "\\", with: ""))")
        
    }
    
    }, responseDataFormatter: nil)

let FmPayProvider = RxMoyaProvider<FmPayService>(plugins:[logPlugin])
let partnerId = "178a14ba-85a8-40c7-9ff4-6418418f5a0c"
let disposeBag = DisposeBag()

extension FmPayService:TargetType {
    var baseURL: URL {
        return URL(string: "http://115.159.117.231:8905/")! //8905
//        return URL(string: "http://172.16.13.236:9000/")!
    }
    
    var path: String {
        switch self {
        case .getPaySign:
//            return "account/pay/unifyOrder"
            return "unifyOrder"
        }
        
    }
    
    var method: Moya.Method {
        switch self {
            case .getPaySign:
                return .post
        }
    }
    
    var parameters: [String : Any]? {
        switch self {
        
        case let .getPaySign(req):
            let dic = jsonToDictionary(jsonString: req.description)
            return dic
       
        }
        
    }
    
    var parameterEncoding: ParameterEncoding {
        switch self {
            case .getPaySign:
                return JSONEncoding.default
        }
    }
    
    
    var sampleData: Data {
        switch self {
            case .getPaySign:
                return "no data".utf8Encoded
        }
    }
    
    var task: Task {
        switch self {
        case .getPaySign:
            return .request
        }
    }
    
}

extension String {
    var urlEscaped: String {
        return self.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    }
    
    var utf8Encoded: Data {
        return self.data(using: .utf8)!
    }
}
