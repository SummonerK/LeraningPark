//
//  ObservableEx.swift
//  XfFruit
//
//  Created by 舒圆波 on 17/6/2.
//  Copyright © 2017年 舒圆波. All rights reserved.
//

import Foundation
import Moya
import RxSwift
import ObjectMapper
import SwiftyJSON



let RESULT_CODE = "statusCode"
let RESULT_MSG = "message"
let RESULT_DATA = "responseData"
public protocol Mapable {
    init?(jsonData:JSON)
}



extension Observable {
    func mapObject<T: Mappable>(type: T.Type) -> Observable<T> {
        return self.map { response in
            //if response is a dictionary, then use ObjectMapper to map the dictionary
            //if not throw an error
            guard let result = response as? Moya.Response else {
                
                throw RxSwiftMoyaError.NoRespons
            }

            // check http status
            guard ((200...209) ~= result.statusCode) else {

                throw RxSwiftMoyaError.NetWorkError
            }
            
            
            let jsonObj = JSON.init(data: result.data)

           
            
            //如果只需要告知成功或失败的返回
            if T.self == BaseResponse.self {
                // check 服务器返回 status
                if jsonObj[RESULT_CODE].int == OurResponseStatus.responseSuccess.rawValue || jsonObj[RESULT_CODE].int == 100{
                    guard let dict = jsonObj.rawValue as? [String:Any] else{
                        throw RxSwiftMoyaError.ParseJSONError
                    }
                    return Mapper<T>().map(JSON: dict)!
                }else{
                    throw OurResponseError.OurError(jsonObj[RESULT_CODE].int!,jsonObj[RESULT_MSG].string!)
                }
            }
//            print("+++\(jsonObj.description)")
            // check 服务器返回 status
            if jsonObj[RESULT_CODE].int == OurResponseStatus.responseSuccess.rawValue || jsonObj[RESULT_CODE].int == 100 {
                guard let dict = jsonObj.rawValue as? [String:Any] else{
                    throw RxSwiftMoyaError.ParseJSONError
                }
                
                return Mapper<T>().map(JSON: dict)!
            }else{
                
                throw OurResponseError.OurError(jsonObj[RESULT_CODE].int!,jsonObj[RESULT_MSG].string!)
            }

        }
    }
    
    
    func mapArray<T: Mappable>(type: T.Type) -> Observable<[T]> {
        return self.map { response in
            //if response is an array of dictionaries, then use ObjectMapper to map the dictionary
            //if not, throw an error
            guard let result = response as? Moya.Response else {
                throw RxSwiftMoyaError.NoRespons
            }
            
            // check http status
            guard ((200...209) ~= result.statusCode) else {
                throw RxSwiftMoyaError.NetWorkError
            }
            
            
            let json = JSON.init(data: result.data)
            // check 服务器返回 status
            if json[RESULT_CODE].int == OurResponseStatus.responseSuccess.rawValue || json[RESULT_CODE].int == 100{
                guard let array = json[RESULT_DATA].rawValue as? [Any] else {
                    throw RxSwiftMoyaError.ParseJSONError
                }
                
                guard let dicts = array as? [[String: Any]] else {
                    throw RxSwiftMoyaError.ParseJSONError
                }
                
                return Mapper<T>().mapArray(JSONArray: dicts)
            }else{
                throw OurResponseError.OurError(json[RESULT_CODE].int!,json[RESULT_MSG].string!)
            }
            
        }
    }
}




enum RxSwiftMoyaError: String {
    case NoRespons = "无响应数据"
    case ParseJSONError = "数据解析错误"
    case OtherError
    case NoDataError = "数据为空"
    case NetWorkError = "网络错误"
    case OurResponseError
}

enum OurResponseStatus: Int {
    case responseSuccess = 0
    case BizError
}

enum OurResponseError {
    case OurError(Int,String)
    var description: (Int,String) {
        switch self {
        case .OurError( let code, let msg):
            return (code,msg)
            
        }
    }
}


extension RxSwiftMoyaError: Swift.Error { }
extension OurResponseError: Swift.Error { }
