//
//  FmPayManager.swift
//  FmOnlinePayApi
//
//  Created by 非码 on 17/8/23.
//  Copyright © 2017年 非码. All rights reserved.
//

import Foundation
import SwiftyRSA
import SwiftyJSON
import ObjectMapper

final class FmPayManager:NSObject,WXApiDelegate {
    
    typealias FmPayCompletionBlock = (_ result:FmPayCallBackRes) -> Void
    var mCurrentBlock:FmPayCompletionBlock!
    var mCallBack:FmPayCallBackRes!
    
    static var shared: FmPayManager {
        struct Static {
            static let instance: FmPayManager = FmPayManager()
        }
        return Static.instance
    }
    
    
    private override init() {}
    
    /*! @brief FmPayManager的成员函数，初始化应用的微信支付appid。
     *@param: wxAppId 微信开放平台所注册的应用的appid
     * 需要在应用appDelegate中初始化调用。
     */
    class func initApi(wxAppId:String) {
        WXApi.registerApp(wxAppId)
        
    }
    
    class func handlePayOpen(url:URL)->Bool {
        print("---\(url.host)")
        if url.scheme == "wx038388890192c0bb" {
            //微信
            return WXApi.handleOpen(url, delegate:FmPayManager.shared)
        }else if url.scheme == "fmsdk" {
            AlipaySDK.defaultService().processOrder(withPaymentResult: url, standbyCallback: {result in
                let status:Int = Int((result!["resultStatus"] as! String))!
                if status != 9000 {
                    FmPayManager.shared.mCallBack.resultCode = status
                    FmPayManager.shared.mCallBack.resultMsg = result!["memo"] != nil ? result!["memo"] as! String : "支付取消"
                    FmPayManager.shared.mCurrentBlock(FmPayManager.shared.mCallBack)
                    return
                }
               
                let resultData:[String:Any] = jsonToDictionary(jsonString: (result!["result"] as! String))
                let response = resultData["alipay_trade_app_pay_response"] as! [String : Any]
                
                FmPayManager.shared.mCallBack.resultCode = 0
                FmPayManager.shared.mCallBack.resultMsg = "支付成功"
                FmPayManager.shared.mCallBack.responseData!.timestamp = response["timestamp"] as? String
                FmPayManager.shared.mCallBack.responseData!.totalAmount = response["total_amount"] as? String
                FmPayManager.shared.mCallBack.responseData!.tradeNo = response["trade_no"] as? String
                FmPayManager.shared.mCallBack.responseData!.sellerId = response["seller_id"] as? String
                FmPayManager.shared.mCallBack.responseData!.outTradeNo = response["out_trade_no"] as? String
                FmPayManager.shared.mCurrentBlock(FmPayManager.shared.mCallBack)
                return
            })
        }else if url.scheme == "FmUPPaySdk" {
            UPPaymentControl.default().handlePaymentResult(url, complete: {(code,data) in
                print("---\(code)---\(data)")
                if code == "fail" {
                    FmPayManager.shared.mCallBack.resultCode = 303
                    FmPayManager.shared.mCallBack.resultMsg = "支付失败"
                    FmPayManager.shared.mCurrentBlock(FmPayManager.shared.mCallBack)
                    return
                }else if code == "cancel" {
                    FmPayManager.shared.mCallBack.resultCode = 303
                    FmPayManager.shared.mCallBack.resultMsg = "支付取消"
                    FmPayManager.shared.mCurrentBlock(FmPayManager.shared.mCallBack)
                    return
                }else if code == "success" {
                    FmPayManager.shared.mCallBack.resultCode = 0
                    FmPayManager.shared.mCallBack.resultMsg = "支付成功"
                    FmPayManager.shared.mCurrentBlock(FmPayManager.shared.mCallBack)
                    return
                }
            })
        }
        return false
    }
    
    /*
        @param:payModel  订单参数
               urlScheme 如使用支付宝 需传入info中配置的scheme,其他传空
               payType   支付类型  暂定 0支付宝  1微信  2银联
                view     当调用银联时需要传入的view视图
               CompletionBlock    回调
     */
    class func createPay(paymentData:String,urlScheme:String,view:ViewController,block:@escaping FmPayCompletionBlock) {
        print("---里面的\(paymentData)")
//        let jsonObj = JSON.init(data: response.data)
        let jsonObj = JSON.init(parseJSON: paymentData)
        print("---\(jsonObj)")
        let payTransformRes:FmWxPrepayRes =  Mapper<FmWxPrepayRes>().map(JSON: jsonObj.rawValue as! [String : Any])!
        
        FmPayManager.shared.mCallBack = FmPayCallBackRes()
        FmPayManager.shared.mCallBack.responseData = FmPayCallBackData()
        
        FmPayManager.shared.mCurrentBlock = block
        let payType:String = payTransformRes.paymentMethodCode!
        if payType != "20002" && payType != "20001" && payType != "20003"{
            FmPayManager.shared.mCallBack.resultCode = 101
            FmPayManager.shared.mCallBack.resultMsg = "支付类型出错"
            block(FmPayManager.shared.mCallBack)
            return
        }
        
        if payTransformRes.statusCode! != 100 {
            FmPayManager.shared.mCallBack.resultCode = payTransformRes.statusCode!
            FmPayManager.shared.mCallBack.resultMsg = payTransformRes.message!
            block(FmPayManager.shared.mCallBack)
            return
        }
        
        FmPayManager.shared.mCallBack.responseData!.fmId = payTransformRes.fmId!
        var signRes = payTransformRes.sign!
        let pbkeyPath = Bundle.main.path(forResource: "public_key", ofType: ".txt")
        var pbKeyStr = ""
        do {
            try pbKeyStr = String(contentsOf: URL(fileURLWithPath: pbkeyPath!), encoding: .utf8)
        } catch  {
            print("---私钥key地址错误")
        }
        let publicKey = try? PublicKey(base64Encoded: pbKeyStr)
//                signRes = "O2cGhVR/cbnHD+QU/o4ET6jXfw7Tfdxti5uL8CsLNTrje98ntPxd+ygs85x081Rp1U+BJI4ACC7bO3T8BUCktoC4hzVRQk5GWZas/Q/bAh6UcYy6wZeLCJJ0A0z14GNp1TD15tgnLbjtPG6b135gHFLu+/J/CEHLLyLmGrt58n8="
        let signature = try? Signature(base64Encoded: signRes)

        var signBefStr = "\(payTransformRes.fmId!)|\(payTransformRes.message!)|\(payTransformRes.payTransId!)|\(payTransformRes.paymentMethod!)|\(payTransformRes.paymentMethodCode!)|\(payTransformRes.statusCode!)|1"
//                signBefStr = "96031709061000004015|成功|online-transid|支付宝app支付|20002|100|1"
        print("---签名前\(signBefStr)")
        let clear = try? ClearMessage(string:signBefStr , using: .utf8)
        let isSignVerify = try? clear?.verify(with: publicKey!, signature: signature!, digestType: .sha1)
        print("---\(isSignVerify!)")
        if (isSignVerify != nil) && !isSignVerify!! {
            return
        }
                
        if payTransformRes.paymentMethodCode == "20002" {
            //支付宝
            FmPayManager.shared.aliDoPay(block: block, scheme: urlScheme, bizContent: (payTransformRes.responseData!.biz_content!))
                    
        }else if payTransformRes.paymentMethodCode == "20001" {
                    //微信
            FmPayManager.shared.wxDoPay(block: block,wxPreRes: payTransformRes)
        }else if payTransformRes.paymentMethodCode == "20003" {
                    //银联
            FmPayManager.shared.unionPay(tn: payTransformRes.responseData!.tn!, scheme: urlScheme, view: view)
        }
        
    }
    
    func wxDoPay(block:@escaping FmPayCompletionBlock,wxPreRes:FmWxPrepayRes) {
        if !WXApi.isWXAppInstalled() {
            FmPayManager.shared.mCallBack.resultCode = 221
            FmPayManager.shared.mCallBack.resultMsg = "没有安装微信"
            block(FmPayManager.shared.mCallBack)
            return
        }
        let payRequest:PayReq = PayReq.init()
        let resData:FmWxPrepayDataRes = wxPreRes.responseData!
        payRequest.openID = resData.appid!
//        payRequest.openID = "wx038388890192c0bb"
    
        payRequest.partnerId = resData.partnerid!
//        payRequest.partnerId = "1485850592"
        payRequest.prepayId = resData.prepayid!
//        payRequest.prepayId = "wx201709121700386778823e920850906626"
        payRequest.package = resData.package!
//        payRequest.package = "Sign=WXPay"
        payRequest.nonceStr = resData.noncestr!
//        payRequest.nonceStr = "1505206848"
        
        payRequest.timeStamp = UInt32(resData.timestamp!)!
//        payRequest.timeStamp = UInt32("1505206838")!
        payRequest.sign = wxPreRes.sign!
//        payRequest.sign = "WbLslkbgtUx83b99ttHqBBP2+3QUZWhcA3kjFhuAzBkHzr/7BgDRedyYitJRlhTIDuJEOriva375XO+noFneO4SjwDty+Lm2my1Ho+mSR30aNeiXZmLeOIyEzrDbEEocuSSPmNxJRESkh5G/PSwVYvPHdqThHyXxcQ+XFT2VllY="
        let isOpenWx:Bool = WXApi.send(payRequest)
        if !isOpenWx {
            FmPayManager.shared.mCallBack.resultCode = 222
            FmPayManager.shared.mCallBack.resultMsg = "打开微信失败"
            block(FmPayManager.shared.mCallBack)
            return
        }
    }
    
    func aliDoPay(block:@escaping FmPayCompletionBlock,scheme:String,bizContent:String) {
        AlipaySDK.defaultService().payOrder(bizContent, fromScheme: scheme, callback: {(result) in
            let resultStatus:Int = Int(result!["resultStatus"] as! String)!
            if resultStatus != 0 {
                FmPayManager.shared.mCallBack.resultCode = resultStatus
                FmPayManager.shared.mCallBack.resultMsg = result!["memo"] as? String
                 block(FmPayManager.shared.mCallBack)
                return
            }
        })
    }
    
    func unionPay(tn:String,scheme:String,view:ViewController) {
        if tn == "" {
            FmPayManager.shared.mCallBack.resultCode = 301
            FmPayManager.shared.mCallBack.resultMsg = "未获取到tn号"
            FmPayManager.shared.mCurrentBlock(FmPayManager.shared.mCallBack)
            return
        }
        UPPaymentControl.default().startPay(tn, fromScheme: scheme, mode: "00", viewController: view)
    }
    
    func onResp(_ resp: BaseResp!) {
        if resp.isKind(of: PayResp.self) {
            let res:PayResp = resp as! PayResp
            if res.errCode != 0 {
                if res.errCode == -2 {
                    FmPayManager.shared.mCallBack.resultCode = -2
                    FmPayManager.shared.mCallBack.resultMsg = "用户取消"
                    FmPayManager.shared.mCurrentBlock(FmPayManager.shared.mCallBack)
                    return
                }
                if res.errCode == -1 {
                    FmPayManager.shared.mCallBack.resultCode = -1
                    FmPayManager.shared.mCallBack.resultMsg = "支付异常(appid异常或其他)"
                    FmPayManager.shared.mCurrentBlock(FmPayManager.shared.mCallBack)
                    return
                }
            }else {
                FmPayManager.shared.mCallBack.resultCode = 0
                FmPayManager.shared.mCallBack.resultMsg = "支付成功"
                FmPayManager.shared.mCurrentBlock(FmPayManager.shared.mCallBack)
                return
            }
        }
    }
}
