//
//  ViewController.swift
//  FmOnlinePayApi
//
//  Created by 舒圆波 on 17/8/23.
//  Copyright © 2017年 舒圆波. All rights reserved.
//

import UIKit
import SwiftyRSA
import SwiftyJSON
import ObjectMapper

class ViewController: UIViewController {
    @IBOutlet var aliBtn: UIButton!
    @IBAction func upDoPay(_ sender: UIButton) {
        initData(type: 3)
    }
    @IBOutlet var textField: UITextField!

    @IBAction func wxDoPay(_ sender: UIButton) {
        initData(type: 2)
    }
    @IBAction func aliDoPay(_ sender: UIButton) {
        initData(type: 1)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    
        
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
       //这里是通过判断点击的vc，如果是银联的 则过滤，如果是你们的，则进入你们的逻辑
        let presentVc = self.presentedViewController
        if presentVc != nil {
            let currentClassName = NSStringFromClass((presentVc?.classForCoder)!)
            if currentClassName == "UPNavController" {
                //TODO touch 银联
                return
            }
        }
        //TODO TOUCH 除了银联， 也可以由这种思路 衍生别的实现方法，都行

    }

    func initData(type:Int) {
        var text = textField.text
        if text == nil || text == "" {
            text = "1447"
        }
        let payModel:FmPrepayModel = FmPrepayModel()
        var payType = ""
        var schemeStr = ""
        payModel.partnerId = Int(text!)!
        payModel.transAmount = 1
        if type == 1 {
            payType = "20002"
            schemeStr = "fmsdk"
        }else if type == 2 {
            payType = "20001"
        }else if type == 3 {
            payType = "20003"
            schemeStr = "FmUPPaySdk"
        }
        payModel.paymentMethodCode = payType
        payModel.partnerOrderId = "\(Int(Date().timeIntervalSince1970))"
        var products:[FmPayProductModel] = []
        for i in 1...1 {
            let product:FmPayProductModel = FmPayProductModel()
            product.pid = "\(i)"
            product.price = 1
            product.name = "商品\(i)"
            product.consumeNum = 1
            products.append(product)
        }
        payModel.products = products
        payModel.storeId = "010"
        let pvkeyPath = Bundle.main.path(forResource: "pb_key", ofType: ".txt")
        var keyStr = ""
        do {
            try keyStr = String(contentsOf: URL(fileURLWithPath: pvkeyPath!), encoding: .utf8)
        } catch  {
            print("---私钥key地址错误")
        }
        print("---\(payModel.description)")
        let privateKey2 = try? PrivateKey(base64Encoded: keyStr)
//        let publicKey = try? PublicKey(base64Encoded: publickeyStr)
        let signBeforeStr = try? ClearMessage(string: "1447|\(payModel.partnerOrderId!)|\(payModel.paymentMethodCode!)|-1|010|1|0|1", using: .utf8)
        
        let signedStr = try? signBeforeStr?.signed(with: privateKey2!, digestType: .sha1)
        
        let base64String = signedStr??.base64String
//        print("---加签后的值\(base64String)")
        
//        let signature = try? Signature(base64Encoded: "\(base64String!)")
       payModel.sign = "\(base64String!)"
        getServeDoPay(payModel: payModel,schemeStr:schemeStr)
        if true {
            return
        }
       
    }
    
    func initDialog(msg:String) {
        // 创建
        let deleteDialog = UIAlertController(title: "支付回调结果", message: msg, preferredStyle:.alert)
        
        // 设置2个UIAlertAction
        let cancelAction = UIAlertAction(title: "确定", style: .cancel, handler: nil)
        
        
        // 添加
        deleteDialog.addAction(cancelAction)
       self.present(deleteDialog, animated: true, completion: nil)
        
        
    }
    
    func getServeDoPay(payModel:FmPrepayModel,schemeStr:String) {
        FmPayProvider.request(.getPaySign(req: payModel))
            .subscribe(onNext: {(response) in
                let str = String.init(data: response.data, encoding: .utf8)
                FmPayManager.createPay(paymentData: str!, urlScheme: schemeStr,view:self, block: {(result) in
                    self.initDialog(msg: "---\(result.resultCode!)----\(result.resultMsg!)---\(result.responseData?.description)")
                })
                
                
                                }, onError: {(error) in
                                    
            }).addDisposableTo(disposeBag)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

