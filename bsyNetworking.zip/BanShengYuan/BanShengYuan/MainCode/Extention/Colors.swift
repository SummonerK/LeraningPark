//
//  Colors.swift
//  BanShengYuan
//
//  Created by Luofei on 2017/6/21.
//  Copyright © 2017年 Luofei. All rights reserved.
//

import Foundation
import UIKit

let FlatBlackDark = UIColor(hexString: "#1D1D1D")
let FlatBlackLight = UIColor(hexString: "#202020")
let FlatGrayDark = UIColor(hexString: "#6D797A")
let FlatGrayLight = UIColor(hexString: "#849495")
let FlatWhiteDark = UIColor(hexString: "#B0B6BB")
let FlatWhiteLight = UIColor(hexString: "#E8ECEE")
let FlatPowderBlueDark = UIColor(hexString: "#8898D0")

