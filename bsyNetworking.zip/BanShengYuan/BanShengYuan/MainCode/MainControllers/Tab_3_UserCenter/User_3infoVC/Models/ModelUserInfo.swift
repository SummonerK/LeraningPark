//
//  ModelUserInfo.swift
//  BanShengYuan
//
//  Created by Luofei on 2017/6/23.
//  Copyright © 2017年 Luofei. All rights reserved.
//

import UIKit

class ModelUserInfo: Reflect {
    /**
     *  编辑昵称
     */
    var nicname:String!
    /**
     *  编辑性别
     */
    var sex:String!
    /**
     *  编辑出生日期
     */
    var birthday:String!
    /**
     *  用户id
     */
    var user_id:String!
    
}
