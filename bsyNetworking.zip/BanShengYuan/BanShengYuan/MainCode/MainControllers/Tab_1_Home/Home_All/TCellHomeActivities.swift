//
//  TCellHomeActivities.swift
//  BanShengYuan
//
//  Created by Luofei on 2017/6/13.
//  Copyright © 2017年 Luofei. All rights reserved.
//

import UIKit

class TCellHomeActivities: UITableViewCell {
    
    @IBOutlet weak var img_left: UIImageView!
    
    
    
    @IBOutlet weak var img_right_down: UIImageView!
    @IBOutlet weak var img_right_up: UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
