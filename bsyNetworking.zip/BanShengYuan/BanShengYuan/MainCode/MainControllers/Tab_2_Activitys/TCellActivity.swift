//
//  TCellActivity.swift
//  BanShengYuan
//
//  Created by Luofei on 2017/6/9.
//  Copyright © 2017年 Luofei. All rights reserved.
//

import UIKit

class TCellActivity: UITableViewCell {

    @IBOutlet weak var imageV_activity: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
