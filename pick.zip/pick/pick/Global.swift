//
//  Global.swift
//  pick
//
//  Created by luofei on 2017/5/24.
//  Copyright © 2017年 luofei. All rights reserved.
//

import Foundation
import UIKit

/// 屏幕宽度
let kScreenWidth = UIScreen.main.bounds.size.width;

func timeintervalToDate(interval:String) -> String {
    let timeString = NSString(string: interval)
    let range = _NSRange(location: 0, length: 10)
    let suString = timeString.substring(with: range)
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd HH:MM:ss"
    let date = NSDate(timeIntervalSince1970: Double(suString)!)
    return compareDate(oldDate: date)
}

func FontPFMedium(size:CGFloat)->UIFont{
    
    return UIFont(name: "PingFangSC-Medium", size: size)!
    
}

func compareDate(oldDate:NSDate) -> String{
    //8小时时差
    let now = NSDate()
    let zone = NSTimeZone.system
    let interval = zone.secondsFromGMT(for: now as Date)
    let localeDate = now.addingTimeInterval(Double(interval))
    let today = localeDate
    
    let newDate = oldDate.addingTimeInterval(Double(interval))
    
    let secondsPerDay:TimeInterval = 24 * 60 * 60
    let yesterday = today.addingTimeInterval(-secondsPerDay)
    let beforeOfYesterday = yesterday.addingTimeInterval(-secondsPerDay)
    let dateString = NSString(string: newDate.description).substring(to: 10)
    let todayString = NSString(string: today.description).substring(to: 10)
    let yesterdayString = NSString(string: yesterday.description).substring(to: 10)
    let beforeOfYesterdayString = NSString(string: beforeOfYesterday.description).substring(to: 10);
    let toYears = NSString(string: today.description).substring(to: 4)
    let dateYears = NSString(string: newDate.description).substring(to: 4)
    let timeH = NSString(string: newDate.description).substring(with: _NSRange(location: 11, length: 5))
    let timeG = NSString(string: newDate.description).substring(with: _NSRange(location: 5, length: 11))
    if toYears == dateYears {
        if dateString == todayString {
            return "今天 \(timeH)"
        } else if dateString == yesterdayString {
            return "昨天 \(timeH)"
        } else if dateString == beforeOfYesterdayString {
            return "前天 \(timeH)"
        } else {
            return timeG
        }
    } else {
        return dateString
    }
}

func getFinalDate(fromDate:NSDate,hour:Int) -> NSDate {
    
    print("hour - \(hour)")
    
    if hour == 0 {
        return fromDate
    }else{
        
        let date = fromDate.addingTimeInterval(TimeInterval(hour*3600))
        
        print(date)
        
        return date
    }
    
}

func getSomeDate(fromeDate:NSDate,days:NSInteger) -> [(String,String,NSDate)] {
    
    let now = fromeDate
    let zone = NSTimeZone.system
    let interval = zone.secondsFromGMT(for: now as Date)
    let localeDate = now.addingTimeInterval(Double(interval))
    var trueinterval = localeDate.timeIntervalSince1970
    trueinterval = trueinterval - trueinterval.truncatingRemainder(dividingBy: 24*3600)
    
    let today = NSDate(timeIntervalSince1970: trueinterval)
    
//    let localSince = localeDate.timeIntervalSinceNow
    
    
    var array = [(String,String,NSDate)]()
    
    for i in 0...days{
        
        let secondsPerDays:TimeInterval = TimeInterval(24 * 60 * 60 * i)
        
        let newdate = NSDate(timeInterval: secondsPerDays, since: today as Date)
    
        print(getDateStringWithY_M_D(WithDate: newdate))
        
        var temp = String()
        
        
        if i == 0{
            temp = "今天"
        }else if i == 1{
            temp = "明天"
        }else{
            temp = weekDay(WithDate: newdate)
        }
        
        let dis = temp
        array.append(getDateStringWithY_M_D(WithDate: newdate),dis,newdate)
        
    }
    
    return array
    
}

// 获取星期几
func weekDay(WithDate:NSDate) -> String {
    
    let weekDays = [NSNull.init(),"周日","周一","周二","周三","周四","周五","周六"] as [Any]
    
    let calendar = NSCalendar.init(calendarIdentifier: .gregorian)
    let timeZone = NSTimeZone.init(name: "Asia/Shanghai")
    calendar?.timeZone = timeZone! as TimeZone
    
    let calendarUnit = NSCalendar.Unit.weekday
    
    let theComponents = calendar?.components(calendarUnit, from: WithDate as Date)
    
    
    return weekDays[(theComponents?.weekday)!] as! String
    
}

//获取当前的年月日 2016-06-15
func getDateStringWithY_M_D(WithDate:NSDate) -> (String){
    let dateFormatter:DateFormatter = DateFormatter.init()
    let timeZone = TimeZone.init(secondsFromGMT: 8)
    dateFormatter.timeZone = timeZone
    dateFormatter.dateFormat = "MM月dd日"
    let dateString:String = dateFormatter.string(from: WithDate as Date)
    return dateString
}

func getHour(withDate:NSDate)->(Int){
    let dateFormatter:DateFormatter = DateFormatter.init()
    dateFormatter.dateFormat = "H"
    let dateString:String = dateFormatter.string(from: withDate as Date)
    return Int(dateString)!
}

//距离当前时间的 天数
func dayTimeDifference(fromDate:NSDate ,toDate:NSDate) -> Double {
//    let anotherSince = toDate.timeIntervalSince(fromDate as Date)
    let nowSince = toDate.timeIntervalSinceNow
    let day = nowSince/(24*3600)
    return ceil(day)
}
