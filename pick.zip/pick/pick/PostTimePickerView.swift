//
//  PostTimePickerView.swift
//  pick
//
//  Created by luofei on 2017/5/24.
//  Copyright © 2017年 luofei. All rights reserved.
//

import UIKit

class PostTimePickerView: UIPickerView,UIPickerViewDelegate,UIPickerViewDataSource{
    
    var arrayDate = [(String(),String(),NSDate())]
    
    open var finalDate = (String(),String(),Int(),Int(),NSDate())
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
        setupSubviews()
//        fatalError("init(coder:) has not been implemented")
    }
    
    func setupSubviews(){
        
        arrayDate = getSomeDate(fromeDate: NSDate(), days: 7)
        
        self.delegate = self
        self.dataSource = self
        
    }
    
    open func setDefaultData(){
        
        if finalDate.0 != ""{
            self.selectRow(finalDate.2,inComponent:0,animated:true)
            self.selectRow(finalDate.3,inComponent:1,animated:true)
        }else{
            let ahour = getHour(withDate: NSDate())
            finalDate.0 = arrayDate[0].0
            finalDate.1 = "\(ahour):00-\(ahour+1):00"
            finalDate.2 = 0
            finalDate.3 = ahour
            finalDate.4 = arrayDate[0].2
            self.selectRow(0,inComponent:0,animated:true)
            self.selectRow(ahour,inComponent:1,animated:true)
        }
    }
    
    ///
    //设置选择框的列数为3列,继承于UIPickerViewDataSource协议
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    //设置选择框的行数为9行，继承于UIPickerViewDataSource协议
    func pickerView(_ pickerView: UIPickerView,
                    numberOfRowsInComponent component: Int) -> Int {
        
        switch component {
        case 0:
            return arrayDate.count
        case 1:
            return 24
        default:
            return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch component {
        case 0:
            finalDate.0 = arrayDate[row].0
            finalDate.2 = row
            finalDate.4 = arrayDate[row].2
        case 1:
            finalDate.1 = "\(row):00-\(row+1):00"
            finalDate.3 = row
        default:
            return
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        let label=UILabel()
        
        switch component {
        case 0:
            //            label.sizeToFit()
            label.font=FontPFMedium(size: 15)
            label.textColor = UIColor.init(colorLiteralRed: 109/255.0, green: 201/255.0, blue: 255/255.0, alpha: 1)
            label.text = arrayDate[row].1+" (\(arrayDate[row].0))"
            label.textAlignment = NSTextAlignment.center
            
            return label
            
        case 1:
            //            label.sizeToFit()
            label.font=FontPFMedium(size: 15)
            label.textColor = UIColor.init(colorLiteralRed: 109/255.0, green: 201/255.0, blue: 255/255.0, alpha: 1)
            label.text = "\(row):00-\(row+1):00"
            label.textAlignment = NSTextAlignment.center
            
            return label
            
        //            label.text=ComponentsInPickerView0[row] as String
        default:
            return label
        }
        
    }
    
    //设置选择框各选项的内容，继承于UIPickerViewDelegate协议
    
    //    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
    //
    //        switch component {
    //        case 0:
    //            let str_temp = NSAttributedString(string: arrayDate[row].1+" (\(arrayDate[row].0))", attributes: [NSForegroundColorAttributeName:UIColor.init(colorLiteralRed: 109/255.0, green: 201/255.0, blue: 255/255.0, alpha: 1)])
    //
    //
    ////            UIFont.init(name: "PingFangSC-Medium", size: 12)!
    //
    //            return str_temp
    //        case 1:
    //
    //            let str_temp = NSAttributedString(string: "\(row):00-\(row+1):00", attributes: [NSForegroundColorAttributeName:UIColor.init(colorLiteralRed: 109/255.0, green: 201/255.0, blue: 255/255.0, alpha: 1)])
    //            return str_temp
    //
    //        default:
    //            return NSAttributedString()
    //        }
    //
    //
    //    }
    
    //delegate
    //设置列宽
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        if(0 == component){
            //第一列变宽
            return kScreenWidth/2
        }else{
            return kScreenWidth/2
        }
    }
    
    //设置行高
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 44
    }


    
    
}
