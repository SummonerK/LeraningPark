//
//  ViewController.swift
//  pick
//
//  Created by luofei on 2017/5/23.
//  Copyright © 2017年 luofei. All rights reserved.
//

import UIKit
import SnapKit

class ViewController: UIViewController{
    
    @IBOutlet weak var btoomSpace: NSLayoutConstraint!
    @IBOutlet weak var newPick: PostTimePickerView!
    
    
    @IBOutlet weak var label_font: UILabel!
    
    @IBOutlet weak var bton_center: UIButton!
    var pickView = UIDatePicker()
    var isopen = Bool()
    @IBOutlet weak var hight: NSLayoutConstraint!
    
    var pickerView:UIPickerView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//        setupPickView()
//        setupUPickView()
        
        isopen = false
        
//        arrayDate = getSomeDate(fromeDate: NSDate(), days: 7)
        
//        for fontFamilyName in UIFont.familyNames
//            
//        {
//            
//            print("family:'%@'",fontFamilyName)
//            
//            for fontName in UIFont.fontNames(forFamilyName: fontFamilyName)
//                
//            {
//                
//                print("\tfont:'%@'",fontName);
//                
//            }
//            
//            print("-------------")
//            
//        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
//    func setupUPickView(){
//        pickerView = UIPickerView()
//        
//        self.view.addSubview(pickerView)
//        pickerView.snp.makeConstraints { (make) in
//            make.top.equalTo(self.view.snp.bottom)
//            make.left.equalTo(self.view)
//            make.right.equalTo(self.view)
//            make.height.equalTo(200)
//        }
//        
//        //设置选择框的默认值
//        pickerView.delegate = self
//        pickerView.dataSource = self
//        
//    }
    
//    func setupPickView() {
//        
//        self.view.addSubview(pickView)
//        pickView.snp.makeConstraints { (make) in
//            make.top.equalTo(self.view.snp.bottom)
//            make.left.equalTo(self.view)
//            make.right.equalTo(self.view)
//            make.height.equalTo(200)
//        }
//        
//        let dformatter = DateFormatter()
//        pickView.datePickerMode = UIDatePickerMode.dateAndTime
//        dformatter.dateFormat = "YYYY-MM-dd: HH"
//        pickView.minuteInterval = 30
//        //将日期选择器区域设置为中文，则选择器日期显示为中文
//        pickView.locale = Locale(identifier: "zh_CN")
//        //注意：action里面的方法名后面需要加个冒号“：”
//        pickView.addTarget(self, action: #selector(dateChanged),
//                             for: .valueChanged)
//        
//    }
    
    //日期选择器响应方法
    func dateChanged(datePicker : UIDatePicker){
        
        //更新提醒时间文本框
        let formatter = DateFormatter()
        //日期样式
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        print(formatter.string(from: datePicker.date))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func pick(_ sender: Any) {

//        isopenDatePick()
//        isopenUPickView()
        
        isOpenNibPick()
    }
    
    @IBAction func ChoosedTime(_ sender: Any) {
        print("选中时间是:\(newPick.finalDate)")
        
        let date = getFinalDate(fromDate: newPick.finalDate.4, hour: newPick.finalDate.3)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 0, options: .transitionCurlDown, animations: { () -> Void in
            self.btoomSpace.constant = -213
            self.isopen = false
        }) { (Bool) -> Void in
        }
        
    }
    
    func isOpenNibPick() {
        if isopen {
            btoomSpace.constant = -213
            isopen = false
        }else{
            btoomSpace.constant = 0
            isopen = true
        }
        newPick.setDefaultData()

    }
    
    
//    func isopenDatePick(){
//        
//        pickView.setDate(NSDate() as Date, animated: true)
//        
//        if isopen {
//            hight.constant = 80
//            bton_center.titleLabel?.font = FontPFMedium(size: 17)
//            pickView.snp.updateConstraints() { (make) in
//                make.top.equalTo(self.view.snp.bottom)
//            }
//            isopen = false
//        }else{
//            hight.constant = 120
//            pickView.snp.updateConstraints { (make) in
//                make.top.equalTo(self.view.snp.bottom).offset(-200)
//            }
//            isopen = true
//        }
//        
//        self.view.layoutIfNeeded()
//    }
    
//    func isopenUPickView(){
//        
//        if isopen {
//            label_font.font = FontPFMedium(size: 17)
//            hight.constant = 80
//            pickerView.snp.updateConstraints() { (make) in
//                make.top.equalTo(self.view.snp.bottom)
//            }
//            isopen = false
//            
//            print("选中时间是:\(finalDate)")
//        }else{
//            
//            label_font.font = FontPFMedium(size: 27)
//            
//            
//            if finalDate.0 != ""{
//                pickerView.selectRow(finalDate.2,inComponent:0,animated:true)
//                pickerView.selectRow(finalDate.3,inComponent:1,animated:true)
//            }else{
//                
//                let ahour = getHour()
//                finalDate.0 = arrayDate[0].0
//                finalDate.1 = "\(ahour):00-\(ahour+1):00"
//                finalDate.2 = 0
//                finalDate.3 = ahour
//                pickerView.selectRow(ahour,inComponent:1,animated:true)
//            }
//            
//            
//            hight.constant = 120
//            pickerView.snp.updateConstraints { (make) in
//                make.top.equalTo(self.view.snp.bottom).offset(-200)
//            }
//            isopen = true
//        }
//        
//        self.view.layoutIfNeeded()
//    }
    
    
}

