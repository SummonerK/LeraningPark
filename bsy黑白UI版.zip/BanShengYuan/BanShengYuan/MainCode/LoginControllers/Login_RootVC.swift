//
//  Login_RootVC.swift
//  
//
//  Created by Luofei on 2017/6/7.
//
//

import UIKit
import IQKeyboardManagerSwift

import RxSwift
import ObjectMapper
import SwiftyJSON

class Login_RootVC: UIViewController{
    @IBOutlet weak var tf_phone: UITextField!
    @IBOutlet weak var tf_pwd: UITextField!
    @IBOutlet weak var bton_login: UIButton!
    @IBOutlet weak var bton_register: UIButton!
    @IBOutlet weak var bton_forget: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setNavi()
        
        setRadiusFor(toview: bton_login, radius: 6, lineWidth: 0, lineColor: UIColor.clear)
        setRadiusFor(toview: bton_register, radius: 6, lineWidth: 0.6, lineColor: FlatGrayDark)
        let attributestr = NSMutableAttributedString(string: "忘记密码", attributes: setUnderLineToString(tocolor: FlatGrayLight))
        
        bton_forget.setAttributedTitle(attributestr, for: UIControlState.normal)
        
        //MARK: 设置键盘
        //键盘监听开关
        IQKeyboardManager.sharedManager().enable = true

        ShowWelecomeV()
        
        
        let disposeBag = DisposeBag()
        let VM = ViewModel()
        
        let model = ModelLoginPost()
        model.partnerId = "a8bee0dd-09d1-4fa9-a9eb-80cb36d3d611"
        model.phone = "13914748543"
        model.password = "697651309772"
        
        VM.loginLogin(amodel: model)
            .subscribe(onNext: { (common:ModelCommonBack) in
                PrintFM("登录\(String(describing: common.description))")
            }, onError: { (error:MyErrorEnum) in
                PrintFM("登陆\(error.drawCodeValue)")
                } as? ((Error) -> Void),
               onCompleted: {
                PrintFM("登陆Completed")
            })
            .addDisposableTo(disposeBag)
        
        let model_address = ModelAddressUpdatePost()
        model_address.partnerId = "a8bee0dd-09d1-4fa9-a9eb-80cb36d3d611"
        model_address.memberId = "3dbab43e-6383-47d5-b176-ea4cad3daf85"
        model_address.receiverName = "03"
        model_address.phone = "18900001111"
        model_address.address = "大街51号"
        model_address.area = "上海-上海-普陀区"
        
        VM.addressUpdate(amodel: model_address)
            .subscribe(onNext: { (common:ModelCommonBack) in
                PrintFM("添加\(String(describing: common.description))")
            }, onError: { (error:MyErrorEnum) in
                PrintFM("添加\(error.drawCodeValue)")
                } as? ((Error) -> Void),
               onCompleted: {
                PrintFM("添加Completed")
            })
            .addDisposableTo(disposeBag)
        
    }
    
    func setNavi() {
        self.navigationItem.title = "账号登录"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func ShowWelecomeV (){
        
        let welecomeV = GuideView.init(frame: UIScreen.main.bounds)
        
        welecomeV.contentImages = {
            
            let array : Array<UIImage> = [BundleImageWithName("guide1")!,BundleImageWithName("guide2")!,BundleImageWithName("guide3")!,BundleImageWithName("guide4")!]
            
            return array
        }
        welecomeV.titles = {
            return ["文章分类,方便阅读","纯黑设计,极客最爱","代码高亮,尊重技术","一键分享,保留精彩"]
        }
        welecomeV.contentSize = {
            return CGSize.init(width: 220, height: 220)
        }
        
        welecomeV.doneButton = {
            let button : UIButton = UIButton(frame:CGRect.init(x: welecomeV.frame.size.width * 0.1, y: welecomeV.frame.size.height - 50, width: welecomeV.frame.size.width * 0.8, height: 33))
            button.setImage(BundleImageWithName("button_start")!, for:UIControlState.normal)
            return button
        }
        
        welecomeV.showGuideView()
        
    }
    
    let duration = 0.3
    
    @IBAction func loginAction(_ sender: Any) {
        PrintFM("登录")
        
        let window = UIApplication.shared.delegate?.window as? UIWindow
        window?.rootViewController = StoryBoard_Main.instantiateInitialViewController()
        
        let animation = CATransition.init()
        animation.duration = duration
//        animation.type = "rippleEffect" //波纹
        animation.type = kCATransitionFade 
        
        UIApplication.shared.keyWindow?.layer.add(animation, forKey: nil)
        
    }
    @IBAction func goToRegist(_ sender: Any) {
        
//        let Vc = self.storyboard?.instantiateViewController(withIdentifier: "RegistVC") as! RegistVC
//        
//        self.present(Vc, animated: false, completion: nil)
//        
//        let animation = CATransition.init()
//        animation.duration = duration
//        //        animation.type = "rippleEffect" //波纹
//        animation.type = kCATransitionFade
//        
//        UIApplication.shared.keyWindow?.layer.add(animation, forKey: nil)
        
    }
    
    @IBAction func goToReSetting(_ sender: Any) {
//        
//        let Vc = self.storyboard?.instantiateViewController(withIdentifier: "getResetCodeVC") as! getResetCodeVC
//        
//        self.present(Vc, animated: false, completion: nil)
//        
//        let animation = CATransition.init()
//        animation.duration = duration
//        //        animation.type = "rippleEffect" //波纹
//        animation.type = kCATransitionFade
//        
//        UIApplication.shared.keyWindow?.layer.add(animation, forKey: nil)
        
    }

}

extension Login_RootVC:UITextFieldDelegate{
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        
        //        PrintFM(string)
        
        if textField == tf_phone , let str = textField.text{
            
            let strLength = str.length - range.length  + string.length
            
            if strLength > 11 {
                return false
            }else if strLength==4 || strLength==5{
                
                PrintFM("\(String(describing: str)) is \(str.isTelNumber())")
                
                return str.isTelNumber()
            }
            
        }
        
        return true
        
    }
    
    
}

