//
//  view_orderHeader.swift
//  BanShengYuan
//
//  Created by Luofei on 2017/6/23.
//  Copyright © 2017年 Luofei. All rights reserved.
//

import UIKit

class view_orderHeader: UIView {
    @IBOutlet weak var label_dianpuname: UILabel!

    @IBOutlet weak var label_wuliu: UILabel!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
